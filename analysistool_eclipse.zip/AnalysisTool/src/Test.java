import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.text.NumberFormatter;

public class Test extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private static JComboBox<String> stateBox;
    private static JComboBox<String> cityBox;
    private static JComboBox<String> jobCategoryBox;
    private static JComboBox<String> jobBox;
    private static JRadioButton locationAnywhere;
    private static JRadioButton locationSpecify;
    
    private static JFormattedTextField radiusField;
    private static JFormattedTextField commuteField;

    private static final int borderGap = 10;
    
    // Create a form with the fields
    public Test() {
        super("Analysis Tool");
        
        UIManager.put("ComboBox.background", new ColorUIResource(Color.WHITE));
        UIManager.put("FormattedTextField.inactiveBackground", getBackground());
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(20 , 20));
        
        
        JPanel jobSelectPanel = new JPanel(new BorderLayout(20,20));
        
        jobSelectPanel.setBorder(BorderFactory.createCompoundBorder(
        		BorderFactory.createCompoundBorder(
        		BorderFactory.createEmptyBorder(borderGap, borderGap, borderGap, borderGap), 
        		BorderFactory.createTitledBorder("Select job category and title")),
        		BorderFactory.createEmptyBorder(borderGap, borderGap, borderGap, borderGap)));
        
        JPanel jobLabelPanel = new JPanel(new GridLayout(2, 1, 0, 5)); // 2 rows 1 column
        jobSelectPanel.add(jobLabelPanel, BorderLayout.WEST);

        JPanel jobFieldPanel = new JPanel(new GridLayout(2, 1, 0, 5)); // 2 rows 1 column
        jobSelectPanel.add(jobFieldPanel, BorderLayout.CENTER);

        JLabel jobCategoryLabel = new JLabel("Category");
        
        jobCategoryBox = new JComboBox<String>(Occupations.instance.getCategories());
        jobCategoryBox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Do something when you select a value
            	String selected = (String)jobCategoryBox.getSelectedItem();
            	if(!selected.equalsIgnoreCase("")){
            		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(Occupations.instance.getJobs(selected));
					jobBox.setModel( model );
					jobBox.setEnabled(true);
            	}
            	else{
            		jobBox.setSelectedIndex(0);
            		jobBox.setEnabled(false);
            	}
            }
        });
        
        JLabel jobTitleLabel = new JLabel("Job Title");
        
        jobBox = new JComboBox<String>(new String[] {""});
        jobBox.setEnabled(false);
        
        jobFieldPanel.add(jobCategoryBox);
        jobFieldPanel.add(jobBox);
        
        jobLabelPanel.add(jobTitleLabel);
        jobLabelPanel.add(jobCategoryLabel);
        
        
        
        JPanel locationPanel = new JPanel(new BorderLayout(20, 5));
        
        locationPanel.setBorder(BorderFactory.createCompoundBorder(
        		BorderFactory.createCompoundBorder(
        		BorderFactory.createEmptyBorder(borderGap, borderGap, borderGap, borderGap), 
        		BorderFactory.createTitledBorder("Select search location")),
        		BorderFactory.createEmptyBorder(borderGap, borderGap, borderGap, borderGap)));
        
        JPanel locationButtonPanel = new JPanel(new BorderLayout(20, 10));
        locationPanel.add(locationButtonPanel, BorderLayout.NORTH);
        
        JPanel locationSelectPanel = new JPanel(new BorderLayout(20, 0));
        locationPanel.add(locationSelectPanel);
        
        JPanel locationCommutePanel = new JPanel(new GridLayout(1, 2, 20, 5));
        locationPanel.add(locationCommutePanel, BorderLayout.SOUTH);
        
        JPanel locationLabelPanel = new JPanel(new GridLayout(4, 1, 0, 5)); // 2 rows 1 column
        locationSelectPanel.add(locationLabelPanel, BorderLayout.WEST);

        JPanel locationFieldPanel = new JPanel(new GridLayout(4, 1, 0, 5)); // 2 rows 1 column
        locationSelectPanel.add(locationFieldPanel, BorderLayout.CENTER);

        locationAnywhere = new JRadioButton("Anywhere");
        locationAnywhere.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Do something when you select a value
            	if(locationSpecify.isSelected())
					stateBox.setEnabled(true);
            	else{
            		stateBox.setSelectedIndex(0);
            		stateBox.setEnabled(false);
            		cityBox.setSelectedIndex(0);
            		cityBox.setEnabled(false);
            	}
            }
        });
        
        
        locationSpecify = new JRadioButton("Within radius of city:");
        locationSpecify.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Do something when you select a value
            	if(locationSpecify.isSelected()){
					stateBox.setEnabled(true);
            		radiusField.setEnabled(true);
                    radiusField.setEditable(true);
            	}
            	else{
            		stateBox.setSelectedIndex(0);
            		stateBox.setEnabled(false);
            		cityBox.setSelectedIndex(0);
            		cityBox.setEnabled(false);
            		radiusField.setEnabled(false);
                    radiusField.setEditable(false);
            	}
            }
        });
        
        
        ButtonGroup locationGroup = new ButtonGroup();
        
        locationGroup.add(locationAnywhere);
        locationGroup.add(locationSpecify);
        
        locationAnywhere.setSelected(true);
        
        JLabel stateLabel = new JLabel("State");
        
        // Options in the combobox
        String[] options = " AL AZ AR CA CO CT DE FL GA ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY".split(" ", -1);
        stateBox = new JComboBox<String>(options);
        stateBox.setEnabled(false);
        stateBox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Do something when you select a value
            	String selected = (String)stateBox.getSelectedItem();
            	if(!selected.equalsIgnoreCase("")){
            		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(USCities.instance.getNames(selected));
					cityBox.setModel( model );
					cityBox.setEnabled(true);
					radiusField.setEnabled(true);
			        radiusField.setEditable(true);
            	}
            	else{
            		stateBox.setSelectedIndex(0);
            		cityBox.setEnabled(false);
            		radiusField.setEnabled(false);
                    radiusField.setEditable(false);
            	}
            }
        });
        
        JLabel cityLabel = new JLabel("City");
        
        cityBox = new JComboBox<String>(new String[] {""});
        cityBox.setEnabled(false);
        
        JLabel radiusLabel = new JLabel("Radius (km)");
        
        NumberFormat radiusFormat = NumberFormat.getInstance();
        NumberFormatter radiusFormatter = new NumberFormatter(radiusFormat);
        radiusFormatter.setValueClass(Integer.class);
        radiusFormatter.setMinimum(0);
        radiusFormatter.setMaximum(10000);
        radiusFormatter.setCommitsOnValidEdit(true);
        radiusField = new JFormattedTextField(radiusFormatter);
        radiusField.setEnabled(false);
        radiusField.setEditable(false);
        
        JLabel commuteLabel = new JLabel("Maximum commute distance (km)");
        
        NumberFormat commuteFormat = NumberFormat.getInstance();
        NumberFormatter commuteFormatter = new NumberFormatter(commuteFormat);
        commuteFormatter.setValueClass(Integer.class);
        commuteFormatter.setMinimum(0);
        commuteFormatter.setMaximum(301);
        commuteFormatter.setCommitsOnValidEdit(true);
        commuteField = new JFormattedTextField(commuteFormatter);
        
        
        locationButtonPanel.add(locationAnywhere, BorderLayout.NORTH);
        locationButtonPanel.add(locationSpecify, BorderLayout.SOUTH);
        
        locationLabelPanel.add(stateLabel);
        locationLabelPanel.add(cityLabel);
        locationLabelPanel.add(radiusLabel);
        
        locationFieldPanel.add(stateBox);
        locationFieldPanel.add(cityBox);
        locationFieldPanel.add(radiusField);
        
        locationCommutePanel.add(commuteLabel, BorderLayout.WEST);
        locationCommutePanel.add(commuteField, BorderLayout.CENTER);
        
        JPanel submitPanel = new JPanel();
       
        // Button submit
        JButton submit = new JButton("Get Best Locations");
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Analyzer.analyze((String) stateBox.getSelectedItem(), 
                		(String) cityBox.getSelectedItem(), 
                		Occupations.instance.getCode((String) jobCategoryBox.getSelectedItem(), (String) jobBox.getSelectedItem()),
                		Integer.parseInt(radiusField.getText()));
            }
        });
        
        submitPanel.add(submit);
        
        
        add(jobSelectPanel, BorderLayout.NORTH);
        add(locationPanel);
        add(submitPanel, BorderLayout.SOUTH);
        pack();
        setVisible(true);
    }

    public static void main(String[] args) {
       final Test form = new Test();
    }

}