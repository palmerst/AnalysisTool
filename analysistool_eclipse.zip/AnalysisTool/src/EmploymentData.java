import java.io.File;
import java.io.FileNotFoundException;
import java.util.TreeMap;
import java.util.HashMap;
import java.util.Scanner;

public class EmploymentData {

	public static EmploymentData instance = new EmploymentData();
	
	private HashMap<String, Double> data;
	
	private EmploymentData(){
		
		data = new HashMap<String, Double>();
		
		try {
			Scanner in = new Scanner(new File("./oe.data.0.Current_clean.csv"));
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split("\t");
				
				if(words[0].charAt(3) != 'M')
					continue;
				
				data.put(words[0], Double.parseDouble(words[1]));
			}
			
			in.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Double getMedianSalary(String jobCode, String locationCode){
		return data.get("OEUM" + locationCode + "000000" + jobCode + "13");
	}
}