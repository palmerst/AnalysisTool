import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Scanner;

public class DataClean {
	
	public static void cleanCities(){
		
	
		try {
			Scanner in = new Scanner(new File("./US.txt"));
			Scanner in_affordability = new Scanner(new File("./homevalues.csv"));
			Scanner in_joblocations = new Scanner(new File("./oe.area_clean.csv"));
			
			PrintStream out = new PrintStream(new File("./US_clean.csv"));
			
			HashSet<String> want = new HashSet<String>();
			HashSet<String> seen = new HashSet<String>();
			
			while(in_affordability.hasNextLine()){
				String line = in_affordability.nextLine();
				String[] words = line.split(",");
				
				want.add(words[0] + ", " + words[1]);
			}
				
			while(in_joblocations.hasNextLine()){
				String line = in_joblocations.nextLine();
				String[] words = line.split("\t");
				
				want.add(words[3]);
			}
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split("\t", -1);
				
				if(seen.contains(words[1] + words[10]))
					continue;
				
				if(want.contains(words[1] + ", " + words[10])){
					out.println(words[1] + "\t" + words[10] + "\t" + words[4] + "\t" + words[5] + "\t" + words[14]);
					seen.add(words[1] + words[10]);
				}
				
//				String nameLower = words[1].toLowerCase();
//				if(nameLower.contains(" of ") || nameLower.contains(" county"))
//					continue;
				
				
//				
//				if(!words[10].isEmpty() && !words[14].isEmpty() && words[6].equals("P")){
//					Integer pop = Integer.parseInt(words[14]);
//					if(pop > 50000){
//						out.println(words[1] + "\t" + words[10] + "\t" + words[4] + "\t" + words[5]);
//						seen.add(words[1] + words[10]);
//					}
//				}
			}
			
			in_affordability.close();
			in_joblocations.close();
			in.close();
			out.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	
	public static void cleanEmp(){
		try {
			Scanner in = new Scanner(new File("./oe.data.0.Current"));
			PrintStream out = new PrintStream(new File("./oe.data.0.Current_clean.csv"));
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split("(\t| )+");
				
				if(words[0].endsWith("13") && !words[3].equalsIgnoreCase("-"))
					out.println(words[0] + "\t" + words[3]);
			}
			
			in.close();
			out.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
