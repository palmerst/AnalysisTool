import java.io.File;
import java.io.FileNotFoundException;
import java.util.TreeMap;
import java.util.HashMap;
import java.util.Scanner;

public class EmploymentLocation {

	public static EmploymentLocation instance = new EmploymentLocation();
	
	private HashMap<City, String> locations;
	
	private EmploymentLocation(){
		
		locations = new HashMap<City, String>();
		
		try {
			Scanner in = new Scanner(new File("./oe.area_clean.csv"));
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split("\t");
			
				if(USCities.instance.cityFromName(words[3]) == null){
					System.out.println("Unknown city: " + words[3]);
					continue;
				}
				
				locations.put(USCities.instance.cityFromName(words[3]), words[1]);
			}
			
			in.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public String getLocation(City c){
		return locations.get(c);
	}
}