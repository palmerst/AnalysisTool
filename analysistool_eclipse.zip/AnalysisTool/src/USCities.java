import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class USCities {

	public static USCities instance = new USCities();
	
	private TreeSet<City> cities;
	private TreeSet<City> largeCities;
	private TreeSet<City> citiesByLat;
	private TreeSet<City> citiesByLon;
	
	private HashMap<String, String> stateToCityNames;
	private HashMap<Integer, City> intToCity;
	private HashMap<City, Integer> cityToInt;
	private HashMap<String, City> nameToCity;
	
	private Integer count; 
	
	private static final String stateStr = "AL AZ AR CA CO CT DE FL GA ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY";
	
	private USCities(){
		
		cities = new TreeSet<City>();
		largeCities = new TreeSet<City>();
		citiesByLat = new TreeSet<City>(new City.LatComparator());
		citiesByLon = new TreeSet<City>(new City.LonComparator());
		
		stateToCityNames = new HashMap<String, String>();
		
		intToCity = new HashMap<Integer, City>();
		cityToInt = new HashMap<City, Integer>();
		
		nameToCity = new HashMap<String, City>();
		
		count = 0;
		
		try {
			Scanner in = new Scanner(new File("./US_clean.csv"));
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split("\t", -1);
				
				if(!stateStr.contains(words[1]))
					continue;
				
				City nextCity = new City(words[0], words[1], Double.parseDouble(words[2]), Double.parseDouble(words[3]));
				cities.add(nextCity);
				citiesByLat.add(nextCity);
				citiesByLon.add(nextCity);
				
				if(Integer.parseInt(words[4]) > 50000)
					largeCities.add(nextCity);
				
				intToCity.put(count, nextCity);
				cityToInt.put(nextCity, count);
				nameToCity.put(words[0] + ", " + words[1], nextCity);
				
				String cityNames = stateToCityNames.get(words[1]);
				if(cityNames == null)
					cityNames = words[0];
				else
					cityNames += "\t" + words[0];
				stateToCityNames.put(words[1], cityNames);
				
				count++;
			}
			
			System.out.println(largeCities.size());
			
			in.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		for(String state : stateToCityNames.keySet()){
			String cityNames = stateToCityNames.get(state);
			String[] cityNamesArray = cityNames.split("\t", -1);
			Arrays.sort(cityNamesArray);
			StringBuilder sb = new StringBuilder();
			for(String name : cityNamesArray)
				sb.append("\t" + name);
			stateToCityNames.put(state, sb.toString());
		}
		
	}
	
	
	public String[] getNames(String state){
		return stateToCityNames.get(state).split("\t", -1);
	}
	
	public Set<City> getCities(){
		return cities;
	}
	
	public Set<City> getLargeCities(){
		return largeCities;
	}
	
	public int cityNumber(City c){
		return cityToInt.get(c);
	}
	
	public City cityAt(Integer i){
		return intToCity.get(i);
	}
	
	public City cityFromName(String s){
		return nameToCity.get(s);
	}
	
	public int cityCount(){
		return count;
	}
	
	public Set<City> getCitiesBetweenLat(Double lat1, Double lat2){
		Set<City> returnSet = new HashSet<City>();
		for(City i : citiesByLat.subSet(new City("", "", lat1, 0.0), new City("", "", lat2, 0.0)))
			returnSet.add(i);
		
		return returnSet;
	}
	
	public Set<City> getCitiesBetweenLon(Double lon1, Double lon2){
		Set<City> returnSet = new HashSet<City>();
		for(City i : citiesByLon.subSet(new City("", "", 0.0, lon1), new City("", "", 0.0, lon2)))
			returnSet.add(i);
		
		return returnSet;
	}
}
