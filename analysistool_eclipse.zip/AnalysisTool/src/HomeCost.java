
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class HomeCost {

	public static HomeCost instance = new HomeCost();
	
	private HashMap<City, Double> sqftPrice;
	
	private HomeCost(){
		
		sqftPrice = new HashMap<City, Double>();
		
		try {
			Scanner in = new Scanner(new File("./homevalues.csv"));
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split(",");
				
				String cityName = words[0] + ", " + words[1];
			
				if(USCities.instance.cityFromName(cityName) == null)
					continue;
				
				
				sqftPrice.put(USCities.instance.cityFromName(cityName), Double.parseDouble(words[2]));
			}
			
			in.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Double getPricePerSqft(City c){
		return sqftPrice.get(c);
	}
}