import java.util.LinkedList;

public class CityRoutes {

	public static CityRoutes route = new CityRoutes();
	
	private class WeightedEdge{
		public Integer end;
		public Double dist;
		
		public WeightedEdge(Integer end, Double dist){
			this.end = end;
			this.dist = dist;
		}
	}
	
	private LinkedList<WeightedEdge>[] routes;
	
	private CityRoutes(){
		
		routes = (LinkedList<WeightedEdge>[]) new LinkedList[USCities.list.cityCount()];
		for(int i = 0; i < USCities.list.cityCount(); i++)
			routes[i] = new LinkedList<WeightedEdge>();
		
		
		City[] cities = USCities.list.getCities().toArray(new City[0]);
		City current;
		Integer currentInt;
		
		for(int i = 0; i < USCities.list.cityCount() - 1; i++){
			current = cities[i];
			currentInt = USCities.list.cityNumber(current);
			
			for(int j = i + 1; j < USCities.list.cityCount(); j++){
				City next = cities[j];
				Integer nextInt = USCities.list.cityNumber(next);
				
				Double distance = current.getDistance(next);
				
				if(distance <= 50.0){
					routes[currentInt].add(new WeightedEdge(nextInt, distance));
					routes[nextInt].add(new WeightedEdge(currentInt, distance));
				}
			}
		}
	}
	
	public void test(){
		System.out.println("SDF");
	}
	
}
