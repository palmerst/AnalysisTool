import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Set;


public class CityRoutes {

	public static CityRoutes instance = new CityRoutes();
	
	private class WeightedEdge{
		public Integer end;
		public Double dist;
		
		public WeightedEdge(Integer end, Double dist){
			this.end = end;
			this.dist = dist;
		}
	}
	
	private LinkedList<WeightedEdge>[] routes;
	
	
	private CityRoutes(String inFile){
		
		routes = (LinkedList<WeightedEdge>[]) new LinkedList[USCities.instance.cityCount()];
		
		for(int i = 0; i < USCities.instance.cityCount(); i++){
			routes[i] = new LinkedList<WeightedEdge>();
		}
		
		try {
			Scanner in = new Scanner(new File(inFile));
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split("\t");
				
				routes[Integer.parseInt(words[0])].add(new WeightedEdge(Integer.parseInt(words[1]), Double.parseDouble(words[2])));
			}
			
			in.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	private CityRoutes(){
		
		routes = (LinkedList<WeightedEdge>[]) new LinkedList[USCities.instance.cityCount()];
		
		for(int i = 0; i < USCities.instance.cityCount(); i++){
			routes[i] = new LinkedList<WeightedEdge>();
		}
		
		
		Set<City> largeCitiesSet = USCities.instance.getLargeCities();
		City[] largeCities = largeCitiesSet.toArray(new City[0]);
		City current;
		Integer currentInt;
		
		Double distMaxLarge = 800.0;
		Double distMax = 150.0;
		
		for(int i = 0; i < largeCities.length; i++){
			current = largeCities[i];
			currentInt = USCities.instance.cityNumber(current);
			
			for(int j = i + 1; j < largeCities.length; j++){
				City next = largeCities[j];
				Integer nextInt = USCities.instance.cityNumber(next);
				
				Double distance = current.getDistance(next);
				
				if(distance <= distMaxLarge){
					routes[currentInt].add(new WeightedEdge(nextInt, distance));
					routes[nextInt].add(new WeightedEdge(currentInt, distance));
				}
			}
			
			Double lat = current.getLat();
			Double lon = current.getLon();
			
			Double distPerLat = 70.0;
			Double distPerLon = Math.toRadians(lat)*70.0;
			
			Set<City> latSet = USCities.instance.getCitiesBetweenLat(lat - distMax/distPerLat, lat + distMax/distPerLat);
			Set<City> lonSet = USCities.instance.getCitiesBetweenLon(lon - distMax/distPerLon, lon + distMax/distPerLon);
			
			latSet.retainAll(lonSet);
			latSet.removeAll(largeCitiesSet);
			
			for(City next : latSet){
				
				Integer nextInt = USCities.instance.cityNumber(next);
				
				Double distance = current.getDistance(next);
				
				if(distance <= distMax){
					routes[currentInt].add(new WeightedEdge(nextInt, distance));
					routes[nextInt].add(new WeightedEdge(currentInt, distance));
				}
			}
		
		}
		
//		try {
//			PrintStream out = new PrintStream(new File("./connectedCities.csv"));
//			
//			for(int i = 0; i < USCities.instance.cityCount(); i++){
//				for(WeightedEdge w : routes[i]){
//					out.println(i + "\t" + w.end + "\t" + w.dist);
//				}
//			}
//			
//			out.close();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	
	public Set<City> citiesWithin(Double distance, City fromCity){
		
		HashSet<City> returnCities = new HashSet<City>();
		
		Double[] d = new Double[USCities.instance.cityCount()];
		Boolean[] unvisited = new Boolean[USCities.instance.cityCount()];
		
		for(int i = 0; i < USCities.instance.cityCount(); i++){
			d[i] = Double.MAX_VALUE;
			unvisited[i] = true;
		}
		
		
		d[USCities.instance.cityNumber(fromCity)] = 0.0;
		
		int count = 0;
		Integer current = null;
		
		while(count != USCities.instance.cityCount()){
			
			Double minSeen = Double.MAX_VALUE;
			for(int i = 0; i < USCities.instance.cityCount(); i++){
				if(!unvisited[i])
					continue;
				if (d[i] < minSeen){
					minSeen = d[i];
					current = i;
				}
			}
			
			if(d[current] > distance)
				break;
			else
				returnCities.add(USCities.instance.cityAt(current));
			
			unvisited[current] = false;
			count++;
			
			for(WeightedEdge w : routes[current]){
				if(unvisited[w.end]){
					if(d[current] + w.dist < d[w.end])
						d[w.end] = d[current] + w.dist;
				}
			}
			
			
		}
		
		return returnCities;
		
		
	}
	
	public void test(){
		System.out.println("SDF");
	}
	
	
}
