import java.util.Comparator;

public class City implements Comparable<City> {

	private String name;
	private String state;
	
	private Double lat;
	private Double lon;
	
	public City(String name, String state, Double lat, Double lon){
		this.name = name;
		this.state = state;
		this.lat = lat;
		this.lon = lon;
	}
	
	public String getState(){
		return state;
	}
	 
	public String getName(){
		return name;
	}
	
	public Double getLat(){
		return lat;
	}
	
	public Double getLon(){
		return lon;
	}
	
	public Double getDistance(City other){
			
		// use Haversine
		Double R = 6371.0;
		Double lat1 = Math.toRadians(this.lat);
		Double lat2 = Math.toRadians(other.lat);
		Double dLat = lat2 - lat1;
		Double dLon = Math.toRadians(other.lon - this.lon);
		
		Double a = Math.sin(dLat/2.0) * Math.sin(dLat/2.0) + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon/2.0) * Math.sin(dLon/2.0);
		Double c = 2.0 * Math.atan2(Math.sqrt(a), Math.sqrt(1.0-a));
		
		return R * c;
			
	}
	
	@Override
	public int hashCode(){
		return (name + ", " + state).hashCode();
	}
	
	@Override
	public boolean equals(Object other){
	    if (other == null) return false;
	    if (other == this) return true;
	    if (!(other instanceof City))return false;
	    City otherCity = (City)other;
	    if (this.compareTo(otherCity) == 0)
	    	return true;
	    return false;
	}

	@Override
	public int compareTo(City o) {

		return (name + ", " + state).compareTo(o.name + ", " + o.state);

	}
	
	@Override
	public String toString(){
		return name + ", " + state;
	}
	
	
	public static class LatComparator implements Comparator<City> {

	    @Override
	    public int compare(City c1, City c2) {
	        if(c1.lat > c2.lat) return 1;
	        if(c1.lat < c2.lat) return -1;
	        if(c1.lon > c2.lon) return 1;
	        if(c1.lon < c2.lon) return -1;
	        return 0;
	    }

	}
	
	public static class LonComparator implements Comparator<City> {

	    @Override
	    public int compare(City c1, City c2) {
	        if(c1.lon > c2.lon) return 1;
	        if(c1.lon < c2.lon) return -1;
	        if(c1.lat > c2.lat) return 1;
	        if(c1.lat < c2.lat) return -1;
	        return 0;
	    }

	}
}
