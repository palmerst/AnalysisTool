
public class Analyzer {

	public static void analyze(String state, String cityName, String occupationCode){
		
		System.out.println("State:\t" + state + "\nCity:\t" + cityName + "\nOccup:\t" + occupationCode);
		CityRoutes.route.test();
	}
	
}
