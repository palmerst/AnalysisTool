import java.util.Set;

public class Analyzer {

	public static void analyze(String jobCode){
		
	}
	
	public static void analyze(String state, String cityName, String jobCode, Integer radius){
		
		Set<City> cities = CityRoutes.instance.citiesWithin(20000.0, USCities.instance.cityFromName(cityName + ", " + state));
	
		int j = 0;
		
		for(City i : cities){
			if(EmploymentLocation.instance.getLocation(i) != null){
				j++;
				if(EmploymentData.instance.getMedianSalary(jobCode, EmploymentLocation.instance.getLocation(i)) != null
					&& HomeCost.instance.getPricePerSqft(i) != null){
					System.out.println(i + "\t" + EmploymentData.instance.getMedianSalary(jobCode, EmploymentLocation.instance.getLocation(i))/(HomeCost.instance.getPricePerSqft(i)/100.0));
				}
			}
		}
		
		System.out.println(j);
	}
	
}
