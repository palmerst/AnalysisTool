import java.io.File;
import java.io.FileNotFoundException;
import java.util.TreeMap;
import java.util.Scanner;

public class Occupations {

	public static Occupations instance = new Occupations();
	
	private TreeMap<String, TreeMap<String, String>> occupations;
	
	private Occupations(){
		
		occupations = new TreeMap<String, TreeMap<String, String>>();
		occupations.put("", null);
		
		try {
			Scanner in = new Scanner(new File("./oe.occupation"));
			
			TreeMap<String, String> current = null;
			
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] words = line.split("\t");
				
				Integer level = Integer.parseInt(words[2]);
				
				if(level == 0){
					current = new TreeMap<String, String>();
					current.put("", null);
					occupations.put(words[1], current);
				}
				
				else if(level < 3)
					continue;
				
				else
					current.put(words[1], words[0]);
				
			}
			
			in.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public String[] getCategories(){
		return occupations.keySet().toArray(new String[0]);
	}

	public String[] getJobs(String category){
		return occupations.get(category).keySet().toArray(new String[0]);
	}
	
	public String getCode(String category, String job){
		return occupations.get(category).get(job);
	}
}