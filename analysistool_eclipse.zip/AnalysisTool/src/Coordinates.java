

public class Coordinates implements Comparable<Coordinates> {

	private final Double latitude;
	private final Double longitude;
	
	public Coordinates(Double latitude, Double longitude){
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	public Double getLat(){
		return latitude;
	}
	
	public Double getLon(){
		return longitude;
	}

	@Override
	public int compareTo(Coordinates o) {
		
		if(latitude > o.latitude)
			return 1;
		if(latitude < o.latitude)
			return -1;
		
		if(longitude > o.longitude)
			return 1;
		if(longitude < o.longitude)
			return -1;
		
		return 0;
	}

	@Override
	public String toString(){
		return "(" + latitude + ", " + longitude + ")";
	}
	
}
